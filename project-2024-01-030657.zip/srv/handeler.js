// handeler.js

const cds = require("@sap/cds");

module.exports.Poststudent = async function (req) {
    console.log("handling POST request for Students");

    // Your logic for handling POST request for Students

    return { result: 'success' }; // Adjust the return based on your logic
};

module.exports._getKpidetail = async function (req) {
    console.log("executed select statement");

    const { tbl1 } = cds.entities();
    const tx = cds.transaction(req);
    const read_data = await tx.run(SELECT.from(tbl1));
    console.log("read data", read_data);
    return read_data;
};

module.exports.postkpidetail = async function (req) {
    console.log("post request executed");

    const { tbl1 } = cds.entities();
    const tx = cds.transaction(req);
    const { ID, Name, Address } = req.data;
    const insertResult = await tx.run(INSERT.into(tbl1).entries([{ Name, Address }]));

    console.log("insert result", insertResult);

    // Check if values array exists and log the inserted data
    if (insertResult.values && insertResult.values.length > 0) {
        const insertedData = insertResult.values[0];
        console.log("inserted data", insertedData);
    }

    return insertResult;
};

module.exports.Postdata = async function (req) {
    console.log("successfully connected frontend and backend");
};

module.exports.Postkpidata = async function (req) {
    console.log("welcome excel file uploading please");
};

module.exports.insertexceldata = async function (req) {
    console.log("execute");
  
};

module.exports.Postkpidata=async function(req){
    console.log("excetue");
}
